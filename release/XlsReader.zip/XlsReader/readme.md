
# XlsReader

... a Processing library that that provides access to .xls (Excel) files.

.xls files are a databaseske and widespread format. This library
provides you with a simple iteratable reader.

## Installation

Latest release:
https://github.com/fjenett/xlsreader-library-processing/raw/latest/release/XlsReader.zip

Current version 0.1.2. has been tested with Processing 3.5.x and 4.1.x. Enjoy.

## Contribute

Please report bugs / if you find any or suggestions if you have any here:
http://github.com/fjenett/xlsreader/issues

---

The library is based upon Apache POI - the Java API for Microsoft Docs
http://poi.apache.org/

fjenett - 2007-2023